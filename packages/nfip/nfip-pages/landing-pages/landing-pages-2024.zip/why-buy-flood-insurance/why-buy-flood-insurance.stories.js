import Component from "./why-buy-flood-insurance.twig";

export default {
  title: "NFIP Pages/Landing Pages/Why Buy Flood Insurance",
};

const Template = (args) => Component(args);

export const WBFI = Template.bind({});
WBFI.storyName = "Why Buy Flood Insurance?";
