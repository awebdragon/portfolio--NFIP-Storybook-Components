import Component from "./mapping-solutions-horizontal.twig";
import DefaultContent from "./content/mapping-solutions-horizontal.json";
import "./mapping-solutions-horizontal.scss";
import "./mapping-solutions-horizontal";

export default {
  title: "NFIP Pages/Landing Pages/Flood Risk Ratings",
};

const Template = (args) => Component(args);

export const FloodRiskRatings = Template.bind({});
FloodRiskRatings.args = DefaultContent;
