setTimeout(() => {
  var tabs = document.querySelectorAll(".nfip-tabs-tab-heading");
  var mobileSelect = document.querySelector(".nfip-tabs-mobile select");

  function handleTabClick() {
    var id = this.id;
    var lastPart = id.split("-").pop();

    var classes = document.querySelector(".nfip-wave-background").classList;

    for (var i = 0; i < classes.length; i++) {
      if (classes[i].startsWith("nfip-wave-position-")) {
        document
          .querySelector(".nfip-wave-background")
          .classList.remove(classes[i]);
      }
    }
    document
      .querySelector(".nfip-wave-background")
      .classList.add("nfip-wave-position-" + lastPart);
  }

  tabs.forEach(function (tab) {
    tab.addEventListener("click", handleTabClick);
  });

  // Mobile version
  function handleSelectAction() {
    console.log(mobileSelect.options[mobileSelect.selectedIndex].text);
    var selectItem = mobileSelect.options[mobileSelect.selectedIndex].text
      .replace(/\s+/g, "")
      .toLowerCase();
    var classes = document.querySelector(".nfip-wave-background").classList;
    for (var i = 0; i < classes.length; i++) {
      if (classes[i].startsWith("nfip-wave-position-")) {
        document
          .querySelector(".nfip-wave-background")
          .classList.remove(classes[i]);
      }
    }
    document
      .querySelector(".nfip-wave-background")
      .classList.add("nfip-wave-position-" + selectItem);
  }
  if (mobileSelect) {
    mobileSelect.addEventListener("change", handleSelectAction.bind(this));
  }
}, 1000);
