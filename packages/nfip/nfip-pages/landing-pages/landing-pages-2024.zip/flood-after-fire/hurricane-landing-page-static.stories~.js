import Component from "./hurricane-landing-page-static.twig";
import "./hurricane-landing-page.scss";
import "./src/Leaves/gwd_webcomponents_v1_min";
import "./src/Leaves/gwdpage_min";
import "./src/Leaves/gwdpagedeck_min";
import "./src/Leaves/gwdparticleeffects_min";
import "./src/Leaves/gwdparticles_min";
import "./hurricane-landing-page";

export default {
  title: "NFIP Pages/Landing Pages",
};

const Template = (args) => Component(args);

export const NFIPHurricaneLandingPageStatic = Template.bind({});
NFIPHurricaneLandingPageStatic.storyName = "Hurricane Landing Page (Static)";
