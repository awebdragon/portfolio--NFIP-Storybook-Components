export const english = {
  sec1: {
    heading: "Change your wildfire story.",
    text: "After a wildfire, there may be rain, mudflow and flood damage. Choose flood insurance and write your own ending.",
    button: {
      link: "https://www.floodsmart.gov/flood-insurance-provider",
      text: "Find an insurance provider",
    },
  },
  sec2: {
    cards: [
      {
        title: "5 Years",
        container_classes:
          "font-family-sans text-center padding-top-205 padding-bottom-205 faf-stat",
        content:
          "Flood risk remains significantly higher until vegetation is restored, about five years or more after a wildfire.",
      },
      {
        title: "4% of homes",
        container_classes:
          "font-family-sans text-center padding-top-205 padding-bottom-205 faf-stat",
        content:
          "In 2024, only 4 percent of homes in states hit by wildfires had National Flood Insurance Program policies.",
      },
    ],
  },
  sec3: {
    heading: "Your new chapter can begin with flood insurance.",
    button: {
      link: "https://www.floodsmart.gov/flood-insurance-provider",
      text: "Find an insurance provider",
    },
  },
  sec4: {
    heading: "Resources to rewrite this story",
    columns: [
      {
        heading: "Read about your flood risk",
        body: "Understanding past floods in your area can help you understand your current flood risk.",
        cta: {
          link: "https://www.floodsmart.gov/historical-nfip-claims-information-and-trends?map=countries/us/us-all&region=us&miny=all&maxy=all&county=&gtype=country",
          link_target: "",
          button_label: "See historical claims",
        },
        extra_classes: "faf-threeup-col",
      },
      {
        heading: "The big picture of buying a policy",
        body: "It’s easy to get flood insurance: Just get in touch with an agent.",
        cta: {
          link: "https://www.floodsmart.gov/how-buy-flood-insurance",
          link_target: "",
          button_label: "Learn how to buy flood insurance",
        },
        extra_classes: "faf-threeup-col",
      },
      {
        heading: "From cover to coverage",
        body: "Know more about the types of policies and what they cover.",
        cta: {
          link: "https://www.floodsmart.gov/whats-covered",
          link_target: "",
          button_label: "Browse policy coverage options",
        },
        extra_classes: "faf-threeup-col",
      },
    ],
  },
  sec5: {
    heading: "Success Story: Turning a new page after Thomas",
    text: "Montecito and Ventura, California, community members were essential to the region’s recovery following the devastating mudflows after the Thomas Fire of January 2018. Their experiences highlight the important role flood insurance plays in disaster preparation.",
    video: "https://www.youtube.com/embed/Gl6qdGGGvFo?si=HLXRl35Awq_54OH_",
  },
  cta: {
    link: "https://www.floodsmart.gov/flood-insurance-provider",
    button_label: "Find an insurance provider",
  },
};

export const spanish = {
  sec1: {
    heading: "Cambie su historia sobre los incendios forestales.",
    text: "Después de un incendio forestal, puede haber lluvias, avalanchas de lodo y daños por inundación. Elija un seguro de inundación y escriba su propio final.",
    button: {
      link: "https://www.floodsmart.gov/es/encuentre",
      text: "Encuentre un proveedor de seguros",
    },
  },
  sec2: {
    cards: [
      {
        title: "5 años",
        container_classes:
          "font-family-sans text-center padding-top-205 padding-bottom-205 faf-stat",
        content:
          "El riesgo de inundación sigue siendo significativamente alto hasta que se restablece la vegetación, lo que puede tardar cinco años o más después de un incendio forestal.",
      },
      {
        title: "4% de viviendas ",
        container_classes:
          "font-family-sans text-center padding-top-205 padding-bottom-205 faf-stat",
        content:
          "En el 2024, solo el 4 por ciento de las viviendas en estados afectados por incendios forestales tenían pólizas del Programa del Seguro Nacional de Inundación.",
      },
    ],
  },
  sec3: {
    heading: "Comience su nuevo capítulo con un seguro de inundación.",
    button: {
      link: "https://www.floodsmart.gov/es/encuentre",
      text: "Encuentre un proveedor de seguros",
    },
  },
  sec4: {
    heading: "Recursos para reescribir esta historia",
    columns: [
      {
        heading: "Conozca su riesgo de inundación",
        body: "Inundaciones pasadas en su zona pueden ayudarle a comprender cuál es su actual riesgo de inundación.",
        cta: {
          link: "https://www.floodsmart.gov/es/informacion-y-tendencias-historicas-las-reclamaciones-del-NFIP?map=countries/us/us-all&region=us&miny=all&maxy=all&county=&gtype=country",
          link_target: "",
          button_label: "Vea los reclamos históricos ",
        },
        extra_classes: "faf-threeup-col",
      },
      {
        heading: "Panorama general sobre la adquisición de una póliza",
        body: "Es fácil obtener un seguro de inundación: solo necesita ponerse en contacto con un agente.",
        cta: {
          link: "https://www.floodsmart.gov/node/145",
          link_target: "",
          button_label: "Conozca cómo adquirir un seguro de inundación ",
        },
        extra_classes: "faf-threeup-col",
      },
      {
        heading: "Cobertura y pólizas",
        body: "Conozca más sobre los tipos de póliza y lo que está cubierto.",
        cta: {
          link: "https://www.floodsmart.gov/whats-covered",
          link_target: "",
          button_label: "Conozca los tipos de cobertura",
        },
        extra_classes: "faf-threeup-col",
      },
    ],
  },
  sec5: {
    heading: "Historias de resiliencia: Pasando la página después de thomas",
    text: "Los residentes de las comunidades de Montecito y Ventura en California fueron esenciales en la recuperación de la región luego de las terribles avalanchas de lodo que siguieron al incendio Thomas de enero de 2018. Sus experiencias destacan el importante papel de un seguro de inundación en la preparación para desastres.",
    video: "https://www.youtube.com/embed/Gl6qdGGGvFo?si=HLXRl35Awq_54OH_",
  },
  cta: {
    link: "https://www.floodsmart.gov/es/encuentre",
    button_label: "Encuentre un proveedor de seguros",
  },
};
