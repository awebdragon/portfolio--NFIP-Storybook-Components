import Component from "./faf.twig";
import "./hurricane-landing-page.scss";
import "./faf.css";

import { english, spanish } from "./content/content";

export default {
  title: "NFIP Pages/Landing Pages/Flood After Fire November 2024",
};

const Template = (args) => Component(args);

export const FloodAfterFire = Template.bind({});
FloodAfterFire.storyName = "Flood After Fire Landing Page";
FloodAfterFire.args = english;

export const FloodAfterFireSpanish = Template.bind({});
FloodAfterFireSpanish.storyName = "Flood After Fire Landing Page (Spanish)";
FloodAfterFireSpanish.args = spanish;

/*
const element = document.querySelector('.usa-button--outline');

// Get the computed styles of the element
const computedStyles = window.getComputedStyle(element);

// Log all computed styles
for (let property of computedStyles) {
  console.log(`${property}: ${computedStyles.getPropertyValue(property)}`);
}
  */
