setTimeout(() => {
  const pauseButton = document.querySelector(".nfip-lp-pause .waves-pause");
  const waveInner = document.querySelectorAll(
    ".waves-inner,.nfip-lp-animation"
  );
  const animations = document.querySelectorAll(".nfip-lp-animation");
  let paused = false;

  if (pauseButton) {
    pauseButton.addEventListener("click", () => {
      waveInner.forEach((el) => {
        console.log(el);
        el.classList.toggle("paused");
      });

      paused = paused ? false : true;
      wavePause.innerHTML = `<span>${paused ? "Play" : "Pause"}</span>`;
    });
  }
  function handleScroll() {}

  window.addEventListener("scroll", handleScroll);
}, 2000);
