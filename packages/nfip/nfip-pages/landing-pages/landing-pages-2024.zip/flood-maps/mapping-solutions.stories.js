import Component from "./mapping-solutions.twig";
import DefaultContent from "../../../nfip-components/nfip-floodzones/content/nfip-floodzones.yml";

export default {
  title: "NFIP Pages/Landing Pages/Flood Maps",
};

const Template = (args) => Component(args);

export const FloodMaps = Template.bind({});
FloodMaps.args = {
  ...DefaultContent,
};
