setTimeout(() => {
  const container = document.getElementById("noaa-demo-filtered");
  if (container) {
    container.innerHTML = "Loading";
    const logs = [];
    const feedback = document.getElementById("feedback");
    const myLocation = document.getElementById("my-location");
    const addressForm = document.getElementById("addressForm");
    const selectedFilter = `&urgency=Immediate,Expected,Future,Unknown&event=Arroyo%20And%20Small%20Stream%20Flood%20Advisory%2CCoastal%20Flood%20Advisory%2CCoastal%20Flood%20Statement%2CCoastal%20Flood%20Warning%2CCoastal%20Flood%20Watch%2CFlash%20Flood%20Statement%2CFlash%20Flood%20Warning%2CFlash%20Flood%20Watch%2CFlood%20Advisory%2CFlood%20Statement%2CFlood%20Warning%2CFlood%20Watch%2CHurricane%20Warning%2CHurricane%20Watch%2CLakeshore%20Flood%20Advisory%2CLakeshore%20Flood%20Statement%2CLakeshore%20Flood%20Warning%2CLakeshore%20Flood%20Watch%2CSmall%20Stream%20Flood%20Advisory%2CStorm%20Surge%20Warning%2CStorm%20Surge%20Watch%2CUrban%20And%20Small%20Stream%20Flood%20Advisory`;

    const globalEndpoint = `https://api.weather.gov/alerts`;

    const nl2p = (input) => {
      const paragraphs = input.split("\n\n");

      return paragraphs
        .filter((line) => line.trim() !== "") // Remove empty lines
        .map((line) => `<p>${line.trim()}</p>`)
        .join("");
    };

    const updateLogs = (msg) => {
      const timestamp = new Date();
      const [h, m, s] = [
        timestamp.getHours(),
        timestamp.getMinutes(),
        timestamp.getSeconds(),
      ];
      logs.unshift([`${h}:${m}:${s}`, msg]);
      feedback.innerHTML = logs
        .map(
          (entry) => `
        <div>${entry[0]}</div>
        <div>${entry[1]}</div>`
        )
        .join("");
    };

    // Getting the alerts
    const renderAlerts = function (alerts) {
      console.log(alerts);
      container.innerHTML = "";
      const { features } = alerts;
      if (features.length) {
        features.forEach((feature) => {
          const { event, headline, description, severity, ends } =
            feature.properties;
          const endDate = new Date(ends);
          const now = new Date();
          const isAlertEnded = now > endDate;

          const eventCard = document.createElement("div");
          if (!isAlertEnded) {
            eventCard.classList.add("event-card");
            eventCard.innerHTML = `
            <div><strong>${event}</strong> <span class="severity-${severity}">${severity}</span></div>
            <h3>${headline}</h3>
            <p>${ends}</p>
            ${nl2p(description)}
            
          `;
          } else {
            container.innerHTML = `There are currently no alerts`;
          }
          container.appendChild(eventCard);
        });
      } else {
        container.innerHTML = "There are currently no alerts";
      }
    };

    const getAlerts = async function (lat, lng) {
      console.log(lat, lng);
      const positionQuery = `point=${lat}%2C${lng}`;
      const endpoint = `${globalEndpoint}?limit=1&${positionQuery}${selectedFilter}`;
      updateLogs(endpoint);

      try {
        const res = await fetch(endpoint);
        const alerts = await res.json();
        renderAlerts(alerts);
      } catch (err) {
        console.log(err);
      }
    };

    // Getting the latitude and longitude from the address submission
    const handleGetCoordsFromAddress = (location) => {
      const { x, y } = location.location;
      updateLogs(`Coordinates for searched address: ${y},${x}`);
      getAlerts(y, x);
    };

    const getCoordsFromAddress = async function (event) {
      event.preventDefault();

      const endpoint = `https://geocode.arcgis.com/arcgis/rest/services/World/GeocodeServer/findAddressCandidates?SingleLine=${encodeURIComponent(
        event.target[0].value
      )}&f=json`;

      updateLogs(`Searching address: ${event.target[0].value}`);
      updateLogs(endpoint);

      try {
        const res = await fetch(endpoint);
        const location = await res.json();
        handleGetCoordsFromAddress(location.candidates[0]);
      } catch (err) {
        console.log(err);
        updateLogs(err);
      }
    };

    // Getting Zipcode from coordinates
    const handleGetZipcode = (address) => {
      updateLogs(`Zipcode detected from location: ${address.address.Postal}`);
      myLocation.value = address.address.Postal;
    };

    const getZipcode = async function (lat, lng) {
      const endpoint = `https://geocode.arcgis.com/arcgis/rest/services/World/GeocodeServer/reverseGeocode?location=${lng},${lat}&f=json`;
      updateLogs(endpoint);

      try {
        const res = await fetch(endpoint);
        const address = await res.json();

        handleGetZipcode(address);
      } catch (err) {
        console.log(err);
        updateLogs(err);
      }
    };

    // Getting Coordinates using geolocation
    const handleGetCoords = (userPosition) => {
      const { latitude, longitude } = userPosition.coords;
      updateLogs(`${latitude}, ${longitude}`);
      getZipcode(latitude, longitude);
      getAlerts(latitude, longitude);
    };

    const getCoords = async function () {
      try {
        navigator.geolocation.getCurrentPosition((position) => {
          userPosition = position;

          handleGetCoords(userPosition);
        });
      } catch (err) {
        console.log(err);
      }
    };

    // Get suggested searches
    const handleGetSuggestedSearches = (results) => {
      console.log("HANDLE GET SUGGESTED SEARCHES");
      console.log(results);
      const places = new Set();
      results.features.forEach((feature) => {
        const areas = feature.properties.areaDesc
          .split(";")
          .map((place) => place.trim());
        areas.forEach((area) => places.add(area));
      });
      console.log(places);
    };

    const getSuggestedSearches = async function () {
      const endpoint = `${globalEndpoint}?limit=20${selectedFilter}`;
      updateLogs(`Get suggested searches: ${endpoint}`);

      try {
        const res = await fetch(endpoint);
        const alerts = await res.json();

        handleGetSuggestedSearches(alerts);
      } catch (err) {
        console.log(err);
        updateLogs(err);
      }
    };

    getCoords();
    addressForm.addEventListener("submit", getCoordsFromAddress);
    getSuggestedSearches();
  }
}, 100);
