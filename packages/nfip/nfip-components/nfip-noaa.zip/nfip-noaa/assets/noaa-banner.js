setTimeout(() => {

  // get the target HTML elements by ID, used by multiple functions
  const noaaAlertContainer = document.getElementById("noaa-alert");

  // set up the API endpoint
  const globalEndpoint = `https://api.weather.gov/alerts`;
  const selectedFilter = `&severity=Minor,Moderate,Severe,Extreme&event=Arroyo%20And%20Small%20Stream%20Flood%20Advisory%2CCoastal%20Flood%20Advisory%2CCoastal%20Flood%20Statement%2CCoastal%20Flood%20Warning%2CCoastal%20Flood%20Watch%2CFlash%20Flood%20Statement%2CFlash%20Flood%20Warning%2CFlash%20Flood%20Watch%2CFlood%20Advisory%2CFlood%20Statement%2CFlood%20Warning%2CFlood%20Watch%2CHurricane%20Warning%2CHurricane%20Watch%2CLakeshore%20Flood%20Advisory%2CLakeshore%20Flood%20Statement%2CLakeshore%20Flood%20Warning%2CLakeshore%20Flood%20Watch%2CSmall%20Stream%20Flood%20Advisory%2CStorm%20Surge%20Warning%2CStorm%20Surge%20Watch%2CUrban%20And%20Small%20Stream%20Flood%20Advisory`;
  // for testing the alert colors - delete when the app is ready!
  // const selectedFilter = `&severity=Minor,Moderate,Severe,Extreme`;

  // retrieve the user's location as latitude and longitude, plug it in to create the final API endpoint, and pull the data
  const handleGetCoords = (userPosition) => {
    const { latitude, longitude } = userPosition.coords;
    getAlerts(latitude, longitude);
  };
  const getCoords = async () => {
    try {
      navigator.geolocation.getCurrentPosition((position) => {
        userPosition = position;
        handleGetCoords(userPosition);
      });
    } catch (err) {
      console.log(err);
    }
  };

  // Pull the data we need from the API and render it
  const renderAlerts = (alerts) => {
    return new Promise((resolve) => {
      // data from API into variable storage for easy use
      const event = alerts.features[0].properties.event;
      const severity = alerts.features[0].properties.severity;

      // get the target HTML elements by ID
      const alertHeading = document.getElementById("noaa-alert-heading");
      const alertBody = document.getElementById("noaa-alert-body");

      // replace the alert heading with the Event value from the API
      alertHeading.innerHTML = `${event}`;

      // add the USWDS alert style/color class, and update the banner body content, based on the severity value
      switch(severity) {
        case "Moderate":
          noaaAlertContainer.classList.add("usa-alert--warning");
          alertBody.innerHTML = `Moderate flooding is likely in your area. Avoid flood-prone areas and be careful on roads. Stay tuned to local news and emergency services, or go <a href="https://www.weather.gov/" target="_blank">weather.gov</a> for updates.`;
          break;
        case "Severe":
        case "Extreme":
          noaaAlertContainer.classList.add("usa-alert--error");
          alertBody.innerHTML = `Significant flooding is likely in your area. Make sure you, your loved ones and your pets are in a safe area. Check local news, emergency services and <a href="https://www.weather.gov/" target="_blank">weather.gov</a> for updates.`;
          break;
        default:
          noaaAlertContainer.classList.add("usa-alert--info");
          alertBody.innerHTML = `There may be some flooding in your area. Take precaution near low-lying areas and avoid standing water. Stay tuned to local news or go <a href="https://www.weather.gov/" target="_blank">weather.gov</a> for updates.`;
      }

      resolve();
    });
    
  };

  // plug in the coordinates and filter to create the final endpoint to pull data from. This is executed inside the handleGetCoords handler above
  const getAlerts = async (lat, long) => {
    // console.log(lat, long);
    const positionQuery = `point=${lat}%2C${long}`;
    const finalEndpoint = `${globalEndpoint}?limit=1&${positionQuery}${selectedFilter}`;

    // attempt to fetch the data from the API, else throw an error in the console log
    try {
      const res = await fetch(finalEndpoint);
      const alerts = await res.json();

      renderAlerts(alerts).then(displayAlert);
    } catch (err) {
      console.log(err);
    }
  };

  // after everything is set up, display the alert if geolocation is available
  const displayAlert = () => {
    if(navigator.geolocation){
      noaaAlertContainer.classList.remove("display-none");
      noaaAlertContainer.removeAttribute("aria-hidden");
    }
  }

  // execute the function to get the user coordinates and pull the data from the API
  getCoords();

}, 100);
