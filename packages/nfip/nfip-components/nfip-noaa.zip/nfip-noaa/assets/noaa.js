import eventTypes from "../data/event-types.js";

function toSnakeCase(str) {
  return str
    .replace(/([a-z])([A-Z])/g, "$1_$2") // Insert underscore between lowercase and uppercase letters
    .replace(/\s+/g, "_") // Replace spaces with underscores
    .replace(/[^\w_]/g, "") // Remove all non-word characters except underscores
    .toLowerCase(); // Convert to lowercase
}

setTimeout(() => {
  // const { eventTypes } = data;

  const container = document.getElementById("noaa-demo");
  if (container) {
    container.innerHTML = "";

    // Getting the weather
    let userPosition = null;

    const renderWeather = function ({ features }) {
      console.log(features);
      weatherContainer.innerHTML =
        userPosition &&
        `<div class="margin-y-4">${userPosition.coords.latitude},${userPosition.coords.longitude}</div>`;
      features.forEach(({ properties }) => {
        const eventItem = document.createElement("div");
        const id = Math.random() * 10000000000000000;
        eventItem.innerHTML = `
        <div><strong>${properties.event}</strong></div>
        <h3>${properties.headline}</h3>
        <p>${properties.description}</p>
        <div class="view-response">
          <label for="response-${id}">View response</label>
          <input type="checkbox" id="response-${id}" class="usa-sr-only">
          <pre>${JSON.stringify(properties, null, 2)}</pre>
        </div>
        <hr>
      `;
        weatherContainer.appendChild(eventItem);
      });

      const json_output = document.createElement("pre");
      json_output.innerHTML = JSON.stringify(features, null, 2);
      weatherContainer.appendChild(json_output);
    };

    const getWeather = async function () {
      const positionQuery = userPosition
        ? `point=${userPosition.coords.latitude}%2C${userPosition.coords.longitude}`
        : "";
      const endpoint = `https://api.weather.gov/alerts?limit=10&${positionQuery}${selectedFilter}`;
      console.log("getWeather()", selectedFilter, positionQuery);
      console.log(endpoint);
      try {
        const res = await fetch(endpoint);
        const weather = await res.json();
        renderWeather(weather);
      } catch (err) {
        console.log(err);
      }
    };

    // Get the event type selection
    let selectedFilter;
    const eventTypeSelect = document.createElement("fieldset");
    eventTypeSelect.innerHTML = "<legend>Select Filters:</legend>";

    const checkboxes = [];
    eventTypeSelect.classList.add("event-type-list", "margin-y-4");

    const handleCheckbox = () => {
      selectedFilter = "";
      const checkboxesChecked = checkboxes
        .filter((checkbox) => checkbox.checked)
        .map((checkbox) => checkbox.value);
      if (checkboxesChecked.length)
        selectedFilter = `&event=${encodeURIComponent(
          checkboxesChecked.join(",")
        )}`;

      getWeather();
    };

    eventTypes.forEach((type) => {
      const { name, checked } = type;
      const id = toSnakeCase(name);
      const checkboxGroup = document.createElement("div");
      const checkbox = document.createElement("input");
      const label = document.createElement("label");

      checkbox.setAttribute("id", id);
      checkbox.setAttribute("value", name);
      checkbox.setAttribute("type", "checkbox");
      checkbox.setAttribute("name", "event_filters");
      if (checked) checkbox.setAttribute("checked", true);

      checkbox.addEventListener("change", handleCheckbox);

      checkboxes.push(checkbox);

      label.setAttribute("for", id);
      label.innerText = name;

      checkboxGroup.appendChild(checkbox);
      checkboxGroup.appendChild(label);

      eventTypeSelect.appendChild(checkboxGroup);
    });

    container.appendChild(eventTypeSelect);

    const weatherContainer = document.createElement("div");
    container.appendChild(weatherContainer);

    const getCoords = async function () {
      try {
        navigator.geolocation.getCurrentPosition((position) => {
          userPosition = position;
          console.log(userPosition);

          handleCheckbox();
        });
      } catch (err) {
        console.log(err);
      }
    };

    // getCoords();
    handleCheckbox();

    // eventTypeSelect.addEventListener("change", (event) => {
    //   console.log("change", selectedFilter, event.target.value);
    //   selectedFilter = event.target.value;
    //   getWeather();
    // });
  }
}, 250);

//https://api.weather.gov/alerts/active?limit=500
