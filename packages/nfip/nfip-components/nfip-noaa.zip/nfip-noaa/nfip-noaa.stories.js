import Component from "./nfip-noaa.twig";
import ComponentFiltered from "./nfip-noaa-filtered.twig";
import ComponentBanner from "./nfip-noaa-banner.twig";
import "./assets/noaa";
import "./assets/noaa-filtered";
import "./assets/noaa-banner";
import "./assets/noaa.scss";

export default {
  title: "NFIP Components/NOAA Alerts API Demo",
};
const Template = (args) => Component(args);
const TemplateFiltered = (args) => ComponentFiltered(args);
const TemplateBanner = (args) => ComponentBanner(args);

// Test versions
// export const NOAAAlerts = Template.bind({});
// export const NOAAAlertsFiltered = TemplateFiltered.bind({});
// NOAAAlertsFiltered.args = {
//   container: "noaa-demo-filtered",
// };

// Final alert banner version
export const NOAAAlertsBanner = TemplateBanner.bind({});