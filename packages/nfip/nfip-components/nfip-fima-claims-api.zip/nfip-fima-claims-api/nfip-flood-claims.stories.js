import ComponentDamages from "./nfip-flood-claims-damages.twig";
import "./src/nfip-flood-claims";

export default {
  title: "NFIP Components/FIMA NFIP Claims API Demo",
};
const TemplateDamages = (args) => ComponentDamages(args);

// Final alert banner version
export const FloodClaimsDamages = TemplateDamages.bind({});
FloodClaimsDamages.storyName = 'Flood Claims - Damages to Properties Year Range Data';