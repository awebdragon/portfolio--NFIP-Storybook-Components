setTimeout(() => {

  const data2014 = require('./data/2014.json');
  const data2015 = require('./data/2015.json');
  const data2016 = require('./data/2016.json');
  const data2017 = require('./data/2017.json');
  const data2018 = require('./data/2018.json');
  const data2019 = require('./data/2019.json');
  const data2020 = require('./data/2020.json');
  const data2021 = require('./data/2021.json');
  const data2022 = require('./data/2022.json');
  const data2023 = require('./data/2023.json');
  const data2024 = require('./data/2024.json');
  
  const averageDamagesElement = document.querySelector('#claims-average-damages');
  const averageDamagesYearlyElement = document.querySelector('#claims-average-damages-years');
  
  let totalAverageDamages = 0;
  let totalAverageDamagesClaims = 0;
  
  let totalAverageReplacement = 0;
  let totalAverageReplacementClaims = 0;
  
  let totalAveragePaid = 0;
  let totalAveragePaidClaims = 0;
  
  
  const getResults2024 = () =>{
    const result = {};
    result.year = 2024;
  
    data2024.forEach(claim => {
      const year = claim.yearOfLoss;
      const contentsDamage = claim.contentsDamageAmount;
      const buildingDamage = claim.buildingDamageAmount;
      const buildingReplacement = claim.buildingReplacementCost;
      const contentsReplacement = claim.contentsReplacementCost;
      const buildingPaid = claim.amountPaidOnBuildingClaim;
      const contentsPaid = claim.amountPaidOnContentsClaim;
      const iccPaid = claim.amountPaidOnIncreasedCostOfComplianceClaim;
    
      if(contentsDamage !== null && contentsDamage !== 0) {
        if(result.contentsDamage){
          result.contentsDamage += contentsDamage;
          result.contentsDamageClaims += 1;
        } else {
          result.contentsDamage = contentsDamage;
          result.contentsDamageClaims = 1;
        };
      };
    
      if(buildingDamage !== null && buildingDamage !== 0) {
        if(result.buildingDamage){
          result.buildingDamage += buildingDamage;
          result.buildingDamageClaims += 1;
        } else {
          result.buildingDamage = buildingDamage;
          result.buildingDamageClaims = 1;
        };
      };
    
      if(buildingReplacement !== null && buildingReplacement !== 0) {
        if(result.buildingReplacement){
          result.buildingReplacement += buildingReplacement;
          result.buildingReplacementClaims += 1;
        } else {
          result.buildingReplacement = buildingReplacement;
          result.buildingReplacementClaims = 1;
        };
      };
    
      if(contentsReplacement !== null && contentsReplacement !== 0) {
        if(result.contentsReplacement){
          result.contentsReplacement += contentsReplacement;
          result.contentsReplacementClaims += 1;
        } else {
          result.contentsReplacement = contentsReplacement;
          result.contentsReplacementClaims = 1;
        };
      };
    
      if(buildingPaid !== null && buildingPaid !== 0) {
        if(result.buildingPaid){
          result.buildingPaid += buildingPaid;
          result.buildingPaidClaims += 1;
        } else {
          result.buildingPaid = buildingPaid;
          result.buildingPaidClaims = 1;
        };
      };
    
      if(contentsPaid !== null && contentsPaid !== 0) {
        if(result.contentsPaid){
          result.contentsPaid += contentsPaid;
          result.contentsPaidClaims += 1;
        } else {
          result.contentsPaid = contentsPaid;
          result.contentsPaidClaims = 1;
        };
      };
    
      if(iccPaid !== null && iccPaid !== 0) {
        if(result.iccPaid){
          result.iccPaid += iccPaid;
          result.iccPaidClaims += 1;
        } else {
          result.iccPaid = iccPaid;
          result.iccPaidClaims = 1;
        };
      };
  
    });
    
    console.log(`${result.year} contents damages: ${(result.contentsDamage / result.contentsDamageClaims)}`);
    averageDamagesElement.textContent = `$${Math.round((result.contentsDamage / result.contentsDamageClaims) + (result.buildingDamage / result.buildingDamageClaims)).toLocaleString()}`;
  
    document.querySelector('#claims-average-replacement').textContent = `Contents: $${result.contentsReplacement / result.contentsReplacementClaims}, and Building: $${result.buildingReplacement / result.buildingReplacementClaims}`;
  }
  
  getResults2024();
  
  }, 200);