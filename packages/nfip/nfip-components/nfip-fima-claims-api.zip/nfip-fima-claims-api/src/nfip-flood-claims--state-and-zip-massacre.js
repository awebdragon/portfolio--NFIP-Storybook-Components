setTimeout(() => {

  const page = document.querySelector('.flsm-fima-redacted-claims-api--container');

  if(page) {

    // eslint-disable-next-line arrow-body-style
    const renderData = (data) => {
      return new Promise((resolve) => {
        // sort the array by the Year of Loss value of each child object. This is so that the HTML display of each item is ordered by year

        // some variables to calculate total damages later.
        let totalDamageSum = 0;
        let totalReplacementSum = 0;
        let averageBuildingDamageSum = 0;
        let averageContentsDamageSum = 0;
        let averageBuildingRepacementSum = 0;
        let averageContentsRepacementSum = 0;

        // We want to create an integer that increases by one for each entry so our entries can have a simple label
        let totalClaimNumber = 0;
        let averageBuildingDamageClaims = 0;
        let averageContentsDamageClaims = 0;
        let averageBuildingRepacementClaims = 0;
        let averageContentsRepacementClaims = 0;

        // min and max year for data filtering
        const minYearFilter = 2020;
        const maxYearFilter = 2024;
        // update the page with the chosen date range
        document.querySelector('#claims-min-year').textContent = minYearFilter;
        document.querySelector('#claims-max-year').textContent = maxYearFilter;

        // now we want to filter the array to find the items with years within that range
        const claimsYearFiltered = data.filter(item => item.yearOfLoss >= minYearFilter && item.yearOfLoss <= maxYearFilter);
        // create an array for all the years within the range
        const yearsArray = [];
        for(let yearArrayItem = minYearFilter; yearArrayItem <= maxYearFilter; yearArrayItem += 1) {
          yearsArray.push(yearArrayItem);
        };

        // grab the content of the damages per year element
        const totalYearlyDamagesElement = document.querySelector('#claims-damages-years');
        // grab the yearly replacement costs list element
        const totalYearlyReplacementElement = document.querySelector('#claims-replacement-years');

        // grab total average damages
        const totalAverageDamagesElement = document.querySelector('#claims-average-damages');

        // grab the yearly average damages list element
        const yearlyAverageDamagesElement = document.querySelector('#claims-average-damages-years');

        // grab the element for the total replacement sum
        const totalReplacementElement = document.querySelector('#claims-total-replacement');

        // grab element for total average replacement costs
        const totalAverageReplacementElement = document.querySelector('#claims-average-replacement');

        // run through a forEach loop to get the values of each claim object - for the whole range - !!!!!! there's some commented code in here, if you're looking to restore the non-state based numbers!!!!!!!
        claimsYearFiltered.forEach(claim => {
          // variables to store the values we need to use
          const contentsDamage = claim.contentsDamageAmount;
          const buildingDamage = claim.buildingDamageAmount;
          const buildingReplacement = claim.buildingReplacementCost;
          const contentsReplacement = claim.contentsReplacementCost;

          // check if ALL building and contents damages and replacements values are null. This will help us tally total results that are NOT averaged.
          if(contentsDamage !== null && contentsDamage !== 0 || buildingDamage !== null && buildingDamage !== 0 || buildingReplacement !== null && buildingReplacement !== 0 || contentsReplacement !== null && contentsReplacement !== 0) {
            totalClaimNumber += 1;
            totalDamageSum += contentsDamage + buildingDamage;
            totalReplacementSum += contentsReplacement + buildingReplacement;
          };

          /*
          // now, count only building damages, for calculating averages
          if(buildingDamage !== null && buildingDamage !== 0) {
            averageBuildingDamageClaims += 1;
            averageBuildingDamageSum += buildingDamage;
          };
          // now, count only contents damages, for calculating averages
          if(contentsDamage !== null && contentsDamage !== 0) {
            averageContentsDamageClaims += 1;
            averageContentsDamageSum += contentsDamage;
          };
          // now, count only building replacement, for calculating averages
          if(buildingReplacement !== null && buildingReplacement !== 0) {
            averageBuildingRepacementClaims += 1;
            averageBuildingRepacementSum += buildingReplacement;
          };
          // now, count only content replacement, for calculating averages
          if(contentsReplacement !== null && contentsReplacement !== 0) {
            averageContentsRepacementClaims += 1;
            averageContentsRepacementSum += contentsReplacement;
          };
          */

        });

        // modify the claims count content
        const claimsCountElement = document.querySelector("#claims-count");
        const claimsCountElement2 = document.querySelector("#claims-count-2");
        const claimsCountYearlyElement = document.querySelector("#claims-count-yearly");
        claimsCountElement.textContent = totalClaimNumber.toLocaleString();
        claimsCountElement2.textContent = totalClaimNumber.toLocaleString();

        /*
        // modify the content for the total damages sum
        const totalDamagesElement = document.querySelector('#claims-total-damages');
        totalDamagesElement.textContent = `$${totalDamageSum.toLocaleString()}`;

        // modify the content for the total replacement sum
        totalReplacementElement.textContent = `$${totalReplacementSum.toLocaleString()}`;

        // modify content for total average damages
        totalAverageDamagesElement.textContent = `$${Math.round((averageBuildingDamageSum / averageBuildingDamageClaims) + (averageContentsDamageSum / averageContentsDamageClaims)).toLocaleString()}`;

        // modify content for total average replacement costs
        totalAverageReplacementElement.textContent = `$${Math.round((averageBuildingRepacementSum / averageBuildingRepacementClaims) + (averageContentsRepacementSum / averageContentsRepacementClaims)).toLocaleString()}`;

        // grab and then modify the yearly average replacement costs list element
        const yearlyAverageReplacementElement = document.querySelector('#claims-average-replacement-years');
        */

        /*
        yearsArray.forEach(yearItem => {
          const result = {};

          // run through a forEach loop to get the values of each claim object - for the yearly values
          claimsYearFiltered.forEach(claim => {
            // variables to store the values we need to use
            const year = claim.yearOfLoss;
            const contentsDamage = claim.contentsDamageAmount;
            const buildingDamage = claim.buildingDamageAmount;
            const buildingReplacement = claim.buildingReplacementCost;
            const contentsReplacement = claim.contentsReplacementCost;

            // check if ALL building contents damages and replacement values are null. We'll need to filter for each property individually to ensure that averages are calculated correctly, but for now we're just removing the ones for which all properties are null or 0
            if(contentsDamage !== null && contentsDamage !== 0 || buildingDamage !== null && buildingDamage !== 0 || buildingReplacement !== null && buildingReplacement !== 0 || contentsReplacement !== null && contentsReplacement !== 0) {

              // calculate yearly values
              if(year === yearItem) {
                // calculate averages for each damage type, since some may be 0 or null. We need to tally the damage, but also tally the new claim count, because we don't want to average against null/0 claim items
                if(contentsDamage !== null && contentsDamage !== 0){
                  if(result.contentsDamage){
                    result.contentsDamage += claim.contentsDamageAmount;
                    result.contentsDamageClaims += 1;
                  } else {
                    result.contentsDamage = claim.contentsDamageAmount;
                    result.contentsDamageClaims = 1;
                  };
                } else if(buildingDamage !== null && buildingDamage !== 0) {
                  if(result.buildingDamage){
                    result.buildingDamage += claim.buildingDamageAmount;
                    result.buildingDamageClaims += 1;
                  } else {
                    result.buildingDamage = claim.buildingDamageAmount;
                    result.buildingDamageClaims = 1;
                  };
                } else if(contentsReplacement !== null && contentsReplacement !== 0) {
                  if(result.contentsReplacement){
                    result.contentsReplacement += claim.contentsReplacementCost;
                    result.contentsReplacementClaims += 1;
                  } else {
                    result.contentsReplacement = claim.contentsReplacementCost;
                    result.contentsReplacementClaims = 1;
                  };
                } else if(buildingReplacement !== null && buildingReplacement !== 0) {
                  if(result.buildingReplacement){
                    result.buildingReplacement += claim.buildingReplacementCost;
                    result.buildingReplacementClaims += 1;
                  } else {
                    result.buildingReplacement = claim.buildingReplacementCost;
                    result.buildingReplacementClaims = 1;
                  };
                };
                
                // calculate totals for each year, no averaging
                if(result.yearDamages){
                  result.yearDamages += claim.contentsDamageAmount + claim.buildingDamageAmount;
                  result.yearReplacements += claim.buildingReplacementCost + claim.contentsReplacementCost;
                  result.claimCount += 1;
                } else{
                  result.yearDamages = claim.contentsDamageAmount + claim.buildingDamageAmount;
                  result.yearReplacements = claim.buildingReplacementCost + claim.contentsReplacementCost;
                  result.claimCount = 1;
                };
              };
            };

          });

          // TOTALS
          const newYearlyClaimCount = document.createElement("li");
          newYearlyClaimCount.textContent = `${yearItem}: ${result.claimCount.toLocaleString()}`;
          claimsCountYearlyElement.appendChild(newYearlyClaimCount);

          const newYearlyListItem = document.createElement("li");
          newYearlyListItem.textContent = `${yearItem}: $${result.yearDamages.toLocaleString()}`;totalYearlyDamagesElement.appendChild(newYearlyListItem);

          const newYearlyReplacementItem = document.createElement("li");
          newYearlyReplacementItem.textContent = `${yearItem}: $${result.yearReplacements.toLocaleString()}`;
          totalYearlyReplacementElement.appendChild(newYearlyReplacementItem);

          // AVERAGES
          const newYearlyAverageDamageItem = document.createElement("li");
          let averageContentsDamagesYearly = 0;
          let averageBuildingDamagesYearly = 0;
          if(Number.isFinite(result.contentsDamage)){
            averageContentsDamagesYearly = result.contentsDamage / result.contentsDamageClaims;
          };
          if(Number.isFinite(result.buildingDamage)){
            averageBuildingDamagesYearly = result.buildingDamage / result.buildingDamageClaims;
          };
          newYearlyAverageDamageItem.textContent = `${yearItem}: $${Math.round(averageContentsDamagesYearly + averageBuildingDamagesYearly).toLocaleString()}`;
          yearlyAverageDamagesElement.appendChild(newYearlyAverageDamageItem);

          const newYearlyAverageReplacementItem = document.createElement("li");

          let averageContentsReplacementsYearly = 0;
          let averageBuildingReplacementsYearly = 0;
          if(Number.isFinite(result.contentsReplacement)){
            averageContentsReplacementsYearly = result.contentsReplacement / result.contentsReplacementClaims;
          };
          if(Number.isFinite(result.buildingReplacement)){
            averageBuildingReplacementsYearly = result.buildingReplacement / result.buildingReplacementClaims;
          };

          newYearlyAverageReplacementItem.textContent = `${yearItem}: $${Math.round(averageContentsReplacementsYearly + averageBuildingReplacementsYearly).toLocaleString()}`;

          yearlyAverageReplacementElement.appendChild(newYearlyAverageReplacementItem);
        });
        */

        /* **************** */
        // now we want to try to collect total and average damages per state, and then damages per zip code per state
        const stateClaimsCount = document.querySelector("#claims-count-states");
        const stateTotalDamages = document.querySelector("#claims-damages-states");
        const stateTotalReplacement = document.querySelector("#claims-replacement-states");
        const stateAverageDamages = document.querySelector("#claims-average-damages-states");
        const stateAverageReplacement = document.querySelector("#claims-average-replacement-states");
        

        // we want to gather all the states and zip codes and put them in arrays to check against, like the states or years, so we can tally up properties by state and zip code. We're going to display the zip codes by which state they belong to.
        const getUniqueValues = (array, key) => {
          const uniqueValues = [];
          const seenValues = new Set();

          // eslint-disable-next-line no-restricted-syntax
          for (const object of array ){
            const value = object[key];
            if(!seenValues.has(value)) {
              uniqueValues.push(value);
              seenValues.add(value);
            };
          };

          return uniqueValues;
        };
        const statesArray = getUniqueValues(claimsYearFiltered, "state");
        const zipCodeArray = getUniqueValues(claimsYearFiltered, "reportedZipCode");
        console.log(statesArray);

        statesArray.forEach(stateItem => {
          const statesResult = {};
          const zipResult = {};

          claimsYearFiltered.forEach(claim => {
            // eslint-disable-next-line prefer-destructuring
            const state = claim.state;
            const zip = claim.reportedZipCode;
            const contentsDamage = claim.contentsDamageAmount;
            const buildingDamage = claim.buildingDamageAmount;
            const buildingReplacement = claim.buildingReplacementCost;
            const contentsReplacement = claim.contentsReplacementCost;

            // check if ALL building contents damages and replacement values are null. We'll need to filter for each property individually to ensure that averages are calculated correctly, but for now we're just removing the ones for which all properties are null or 0
            if(contentsDamage !== null && contentsDamage !== 0 || buildingDamage !== null && buildingDamage !== 0 || buildingReplacement !== null && buildingReplacement !== 0 || contentsReplacement !== null && contentsReplacement !== 0) {
              if(state === stateItem) {
                // calculate averages for each damage type, since some may be 0 or null. We need to tally the damage, but also tally the new claim count, because we don't want to average against null/0 claim items
                if(contentsDamage !== null && contentsDamage !== 0){
                  if(statesResult.contentsDamage){
                    statesResult.contentsDamage += claim.contentsDamageAmount;
                    statesResult.contentsDamageClaims += 1;
                  } else {
                    statesResult.contentsDamage = claim.contentsDamageAmount;
                    statesResult.contentsDamageClaims = 1;
                  };
                } else if(buildingDamage !== null && buildingDamage !== 0) {
                  if(statesResult.buildingDamage){
                    statesResult.buildingDamage += claim.buildingDamageAmount;
                    statesResult.buildingDamageClaims += 1;
                  } else {
                    statesResult.buildingDamage = claim.buildingDamageAmount;
                    statesResult.buildingDamageClaims = 1;
                  };
                } else if(contentsReplacement !== null && contentsReplacement !== 0) {
                  if(statesResult.contentsReplacement){
                    statesResult.contentsReplacement += claim.contentsReplacementCost;
                    statesResult.contentsReplacementClaims += 1;
                  } else {
                    statesResult.contentsReplacement = claim.contentsReplacementCost;
                    statesResult.contentsReplacementClaims = 1;
                  };
                } else if(buildingReplacement !== null && buildingReplacement !== 0) {
                  if(statesResult.buildingReplacement){
                    statesResult.buildingReplacement += claim.buildingReplacementCost;
                    statesResult.buildingReplacementClaims += 1;
                  } else {
                    statesResult.buildingReplacement = claim.buildingReplacementCost;
                    statesResult.buildingReplacementClaims = 1;
                  };
                };
              };
            };
          });

          // update state claims count
          const newStateClaimCount = document.createElement("li");
          let totalStateClaimCount = 0;
          if(Number.isFinite((statesResult.contentsDamageClaims + statesResult.buildingDamageClaims + statesResult.buildingReplacementClaims + statesResult.contentsReplacementClaims))){
            totalStateClaimCount = statesResult.contentsDamageClaims + statesResult.buildingDamageClaims + statesResult.buildingReplacementClaims + statesResult.contentsReplacementClaims;
          };
          newStateClaimCount.textContent = `${stateItem}: ${totalStateClaimCount.toLocaleString()}`;
          stateClaimsCount.appendChild(newStateClaimCount);

          // update state total damages list. During the zip code phase below, we'll also be appending an additional list with list items to each of these list items. Hopefully.


          // now for the zip codes loop
          claimsYearFiltered.forEach(claim => {
            // eslint-disable-next-line prefer-destructuring
            const state = claim.state;
            const zip = claim.reportedZipCode;
            const contentsDamage = claim.contentsDamageAmount;
            const buildingDamage = claim.buildingDamageAmount;
            const buildingReplacement = claim.buildingReplacementCost;
            const contentsReplacement = claim.contentsReplacementCost;

            // check if ALL building contents damages and replacement values are null. We'll need to filter for each property individually to ensure that averages are calculated correctly, but for now we're just removing the ones for which all properties are null or 0
            if(contentsDamage !== null && contentsDamage !== 0 || buildingDamage !== null && buildingDamage !== 0 || buildingReplacement !== null && buildingReplacement !== 0 || contentsReplacement !== null && contentsReplacement !== 0) {
              if(state === stateItem) {
                zipCodeArray.forEach(zipItem => {
                  if(zip === zipItem) {
                    // calculate averages for each damage type, since some may be 0 or null. We need to tally the damage, but also tally the new claim count, because we don't want to average against null/0 claim items
                    if(contentsDamage !== null && contentsDamage !== 0){
                      if(zipResult.contentsDamage){
                        zipResult.contentsDamage += claim.contentsDamageAmount;
                        zipResult.contentsDamageClaims += 1;
                      } else {
                        zipResult.contentsDamage = claim.contentsDamageAmount;
                        zipResult.contentsDamageClaims = 1;
                      };
                    } else if(buildingDamage !== null && buildingDamage !== 0) {
                      if(zipResult.buildingDamage){
                        zipResult.buildingDamage += claim.buildingDamageAmount;
                        zipResult.buildingDamageClaims += 1;
                      } else {
                        zipResult.buildingDamage = claim.buildingDamageAmount;
                        zipResult.buildingDamageClaims = 1;
                      };
                    } else if(contentsReplacement !== null && contentsReplacement !== 0) {
                      if(zipResult.contentsReplacement){
                        zipResult.contentsReplacement += claim.contentsReplacementCost;
                        zipResult.contentsReplacementClaims += 1;
                      } else {
                        zipResult.contentsReplacement = claim.contentsReplacementCost;
                        zipResult.contentsReplacementClaims = 1;
                      };
                    } else if(buildingReplacement !== null && buildingReplacement !== 0) {
                      if(zipResult.buildingReplacement){
                        zipResult.buildingReplacement += claim.buildingReplacementCost;
                        zipResult.buildingReplacementClaims += 1;
                      } else {
                        zipResult.buildingReplacement = claim.buildingReplacementCost;
                        zipResult.buildingReplacementClaims = 1;
                      };
                    };
                  };

                  // now to update the child zip codes.... this may lag the page by a lot.
                  const newZipElement = document.createElement("li");
                  let totalZipClaimCount = 0;
                  if(Number.isFinite((zipResult.contentsDamageClaims + zipResult.buildingDamageClaims + zipResult.buildingReplacementClaims + zipResult.contentsReplacementClaims))){
                    totalZipClaimCount = zipResult.contentsDamageClaims + zipResult.buildingDamageClaims + zipResult.buildingReplacementClaims + zipResult.contentsReplacementClaims;
                  };
                  newStateClaimCount.textContent = `${zipItem}: ${totalZipClaimCount.toLocaleString()}`;
                  newStateClaimCount.appendChild(newZipElement);
                });
              };
            };
          });
        });

        resolve();
      })
    }
    
    const fetchData = async () => {
      // const endpoint = "https://www.fema.gov/api/open/v2/FimaNfipClaims?$format=jsona";

      // const data2014 = require('./data/2014.json');
      // const data2015 = require('./data/2015.json');
      // const data2016 = require('./data/2016.json');
      // const data2017 = require('./data/2017.json');
      // const data2018 = require('./data/2018.json');
      // const data2019 = require('./data/2019.json');
      const data2020 = require('./data/2020.json');
      const data2021 = require('./data/2021.json');
      const data2022 = require('./data/2022.json');
      const data2023 = require('./data/2023.json');
      const data2024 = require('./data/2024.json');

      const allData = data2020.concat(data2021,data2022,data2023,data2024);

      renderData(allData);
    }

    fetchData();

  };

}, 200);