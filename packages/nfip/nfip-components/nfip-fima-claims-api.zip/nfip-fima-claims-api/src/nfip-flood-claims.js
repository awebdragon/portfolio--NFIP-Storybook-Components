setTimeout(() => {

  const page = document.querySelector('.flsm-fima-redacted-claims-api--container');

  if(page) {

    // eslint-disable-next-line arrow-body-style
    const renderData = (data) => {
      return new Promise((resolve) => {
        // sort the array by the Year of Loss value of each child object. This is so that the HTML display of each item is ordered by year

        // some variables to calculate total damages later.
        let totalDamageSum = 0;
        let totalReplacementSum = 0;
        let averageBuildingDamageSum = 0;
        let averageContentsDamageSum = 0;
        let averageBuildingRepacementSum = 0;
        let averageContentsRepacementSum = 0;
        // total paid
        let averageBuildingPaidSum = 0;
        let averageContentsPaidSum = 0;
        let averageICCPaidSum = 0;

        // We want to create an integer that increases by one for each entry so our entries can have a simple label
        let totalClaimNumber = 0;
        let averageBuildingDamageClaims = 0;
        let averageContentsDamageClaims = 0;
        let averageBuildingRepacementClaims = 0;
        let averageContentsRepacementClaims = 0;
        // for paid
        let averageBuildingPaidClaims = 0;
        let averageContentsPaidClaims = 0;
        let averageICCPaidClaims = 0;

        // min and max year for data filtering
        const minYearFilter = 2014;
        const maxYearFilter = 2024;
        // update the page with the chosen date range
        document.querySelector('#claims-min-year').textContent = minYearFilter;
        document.querySelector('#claims-max-year').textContent = maxYearFilter;
        // now we want to filter the array to find the items with years within that range
        const claimsYearFiltered = data.filter(item => item.yearOfLoss >= minYearFilter && item.yearOfLoss <= maxYearFilter);
        // create an array for all the years within the range
        const yearsArray = [];
        for(let yearArrayItem = minYearFilter; yearArrayItem <= maxYearFilter; yearArrayItem += 1) {
          yearsArray.push(yearArrayItem);
        };

        // grab the content of the damages per year element
        const totalYearlyDamagesElement = document.querySelector('#claims-damages-years');
        // grab the yearly replacement costs list element
        const totalYearlyReplacementElement = document.querySelector('#claims-replacement-years');

        // grab total average damages
        const totalAverageDamagesElement = document.querySelector('#claims-average-damages');

        // grab the yearly average damages list element
        const yearlyAverageDamagesElement = document.querySelector('#claims-average-damages-years');

        // grab the element for the total replacement sum
        const totalReplacementElement = document.querySelector('#claims-total-replacement');

        // grab element for total average replacement costs
        const totalAverageReplacementElement = document.querySelector('#claims-average-replacement');

        // grab the elements needed for the paid claims amounts
        const totalPaidElement = document.querySelector('#claims-total-paid');
        const totalAveragePaidElement = document.querySelector('#claims-average-paid');
        const yearlyTotalPaidElement = document.querySelector('#claims-paid-years');
        const yearlyAveragePaidElement = document.querySelector('#claims-average-paid-years');

        // run through a forEach loop to get the values of each claim object - for the whole range
        claimsYearFiltered.forEach(claim => {
          // variables to store the values we need to use
          const contentsDamage = claim.contentsDamageAmount;
          const buildingDamage = claim.buildingDamageAmount;
          const buildingReplacement = claim.buildingReplacementCost;
          const contentsReplacement = claim.contentsReplacementCost;
          const buildingPaid = claim.amountPaidOnBuildingClaim;
          const contentsPaid = claim.amountPaidOnContentsClaim;
          const iccPaid = claim.amountPaidOnIncreasedCostOfComplianceClaim;

          // check if ALL building and contents damages and replacements values are null. This will help us tally total results that are NOT averaged.
          if(contentsDamage !== null && contentsDamage !== 0 || buildingDamage !== null && buildingDamage !== 0 || buildingReplacement !== null && buildingReplacement !== 0 || contentsReplacement !== null && contentsReplacement !== 0) {
            totalClaimNumber += 1;
            totalDamageSum += contentsDamage + buildingDamage;
            totalReplacementSum += contentsReplacement + buildingReplacement;
          };

          // now, count only building damages, for calculating averages
          if(buildingDamage !== null && buildingDamage !== 0) {
            averageBuildingDamageClaims += 1;
            averageBuildingDamageSum += buildingDamage;
          };
          // now, count only contents damages, for calculating averages
          if(contentsDamage !== null && contentsDamage !== 0) {
            averageContentsDamageClaims += 1;
            averageContentsDamageSum += contentsDamage;
          };
          // now, count only building replacement, for calculating averages
          if(buildingReplacement !== null && buildingReplacement !== 0) {
            averageBuildingRepacementClaims += 1;
            averageBuildingRepacementSum += buildingReplacement;
          };
          // now, count only content replacement, for calculating averages
          if(contentsReplacement !== null && contentsReplacement !== 0) {
            averageContentsRepacementClaims += 1;
            averageContentsRepacementSum += contentsReplacement;
          };

          // count up the paid amounts, used for both averaging and totaling so that the statements aren't separated
          if(buildingPaid !== null && buildingPaid !== 0) {
            averageBuildingPaidClaims += 1;
            averageBuildingPaidSum += buildingPaid;
          };
          if(contentsPaid !== null && contentsPaid !== 0) {
            averageContentsPaidClaims += 1;
            averageContentsPaidSum += contentsPaid;
          };
          if(iccPaid !== null && iccPaid !== 0) {
            averageICCPaidClaims += 1;
            averageICCPaidSum += iccPaid;
          };

        });

        // modify the claims count content
        const claimsCountElement = document.querySelector("#claims-count");
        const claimsCountElement2 = document.querySelector("#claims-count-2");
        const claimsCountYearlyElement = document.querySelector("#claims-count-yearly");
        claimsCountElement.textContent = totalClaimNumber.toLocaleString();
        claimsCountElement2.textContent = totalClaimNumber.toLocaleString();

        // modify the content for the total damages sum
        const totalDamagesElement = document.querySelector('#claims-total-damages');
        totalDamagesElement.textContent = `$${totalDamageSum.toLocaleString()}`;

        // modify the content for the total replacement sum
        totalReplacementElement.textContent = `$${totalReplacementSum.toLocaleString()}`;

        // modify content for total average damages
        totalAverageDamagesElement.textContent = `$${Math.round((averageBuildingDamageSum / averageBuildingDamageClaims) + (averageContentsDamageSum / averageContentsDamageClaims)).toLocaleString()}`;

        // modify content for total average replacement costs
        totalAverageReplacementElement.textContent = `$${Math.round((averageBuildingRepacementSum / averageBuildingRepacementClaims) + (averageContentsRepacementSum / averageContentsRepacementClaims)).toLocaleString()}`;

        // modify content for total and average total claims paid amounts
        totalPaidElement.textContent = `$${Math.round(averageBuildingPaidSum + averageContentsPaidSum + averageICCPaidSum).toLocaleString()}`;

        totalAveragePaidElement.textContent = `$${Math.round((averageBuildingPaidSum / averageBuildingPaidClaims) + (averageContentsPaidSum / averageContentsPaidClaims) + (averageICCPaidSum / averageICCPaidClaims)).toLocaleString()}`;

        // grab and then modify the yearly average replacement costs list element
        const yearlyAverageReplacementElement = document.querySelector('#claims-average-replacement-years');
        yearsArray.forEach(yearItem => {
          const result = {};

          // run through a forEach loop to get the values of each claim object - for the yearly values
          claimsYearFiltered.forEach(claim => {
            // variables to store the values we need to use
            const year = claim.yearOfLoss;
            const contentsDamage = claim.contentsDamageAmount;
            const buildingDamage = claim.buildingDamageAmount;
            const buildingReplacement = claim.buildingReplacementCost;
            const contentsReplacement = claim.contentsReplacementCost;
            const buildingPaid = claim.amountPaidOnBuildingClaim;
            const contentsPaid = claim.amountPaidOnContentsClaim;
            const iccPaid = claim.amountPaidOnIncreasedCostOfComplianceClaim;

            // check if ALL building contents damages and replacement values are null. We'll need to filter for each property individually to ensure that averages are calculated correctly, but for now we're just removing the ones for which all properties are null or 0
            if(contentsDamage !== null && contentsDamage !== 0 || buildingDamage !== null && buildingDamage !== 0 || buildingReplacement !== null && buildingReplacement !== 0 || contentsReplacement !== null && contentsReplacement !== 0) {

              // calculate yearly values
              if(year === yearItem) {
                // calculate averages for each damage type, since some may be 0 or null. We need to tally the damage, but also tally the new claim count, because we don't want to average against null/0 claim items
                if(contentsDamage !== null && contentsDamage !== 0){
                  if(result.contentsDamage){
                    result.contentsDamage += claim.contentsDamageAmount;
                    result.contentsDamageClaims += 1;
                  } else {
                    result.contentsDamage = claim.contentsDamageAmount;
                    result.contentsDamageClaims = 1;
                  };
                };
                if(buildingDamage !== null && buildingDamage !== 0) {
                  if(result.buildingDamage){
                    result.buildingDamage += claim.buildingDamageAmount;
                    result.buildingDamageClaims += 1;
                  } else {
                    result.buildingDamage = claim.buildingDamageAmount;
                    result.buildingDamageClaims = 1;
                  };
                };

                // replacement costs
                if(contentsReplacement !== null && contentsReplacement !== 0) {
                  if(result.contentsReplacement){
                    result.contentsReplacement += claim.contentsReplacementCost;
                    result.contentsReplacementClaims += 1;
                  } else {
                    result.contentsReplacement = claim.contentsReplacementCost;
                    result.contentsReplacementClaims = 1;
                  };
                };
                if(buildingReplacement !== null && buildingReplacement !== 0) {
                  if(result.buildingReplacement){
                    result.buildingReplacement += claim.buildingReplacementCost;
                    result.buildingReplacementClaims += 1;
                  } else {
                    result.buildingReplacement = claim.buildingReplacementCost;
                    result.buildingReplacementClaims = 1;
                  };
                };
                
                // calculate total damages for each year, no averaging
                if(result.yearDamages){
                  result.yearDamages += claim.contentsDamageAmount + claim.buildingDamageAmount;
                  result.yearReplacements += claim.buildingReplacementCost + claim.contentsReplacementCost;
                  result.claimCount += 1;
                } else{
                  result.yearDamages = claim.contentsDamageAmount + claim.buildingDamageAmount;
                  result.yearReplacements = claim.buildingReplacementCost + claim.contentsReplacementCost;
                  result.claimCount = 1;
                };

                // calculate average paid amounts for yearly averages
                if(buildingPaid !== null && buildingPaid !== 0) {
                  if(result.buildingPaid){
                    result.buildingPaid += buildingPaid;
                    result.buildingPaidClaims += 1;
                  } else {
                    result.buildingPaid = buildingPaid;
                    result.buildingPaidClaims = 1;
                  };
                };
                if(contentsPaid !== null && contentsPaid !== 0) {
                  averageContentsPaidClaims += 1;
                  averageContentsPaidSum += contentsPaid;
                  if(result.contentsPaid){
                    result.contentsPaid += contentsPaid;
                    result.contentsPaidClaims += 1;
                  } else {
                    result.contentsPaid = contentsPaid;
                    result.contentsPaidClaims = 1;
                  };
                };
                if(iccPaid !== null && iccPaid !== 0) {
                  averageICCPaidClaims += 1;
                  averageICCPaidSum += iccPaid;
                  if(result.iccPaid){
                    result.iccPaid += iccPaid;
                    result.iccPaidClaims += 1;
                  } else {
                    result.iccPaid = iccPaid;
                    result.iccPaidClaims = 1;
                  };
                };
              };
            };

          });

          // TOTALS yearly
          const newYearlyClaimCount = document.createElement("li");
          newYearlyClaimCount.textContent = `${yearItem}: ${result.claimCount.toLocaleString()}`;
          claimsCountYearlyElement.appendChild(newYearlyClaimCount);

          const newYearlyListItem = document.createElement("li");
          newYearlyListItem.textContent = `${yearItem}: $${result.yearDamages.toLocaleString()}`;totalYearlyDamagesElement.appendChild(newYearlyListItem);

          const newYearlyReplacementItem = document.createElement("li");
          newYearlyReplacementItem.textContent = `${yearItem}: $${result.yearReplacements.toLocaleString()}`;
          totalYearlyReplacementElement.appendChild(newYearlyReplacementItem);

          const newYearlyClaimsPaidItem = document.createElement("li");
          newYearlyClaimsPaidItem.textContent = `${yearItem}: $${Math.round(result.buildingPaid + result.contentsPaid).toLocaleString()}`;
          yearlyTotalPaidElement.appendChild(newYearlyClaimsPaidItem);

          // AVERAGES yearly
          const newYearlyAverageDamageItem = document.createElement("li");
          let averageContentsDamagesYearly = 0;
          let averageBuildingDamagesYearly = 0;
          if(Number.isFinite(result.contentsDamage)){
            averageContentsDamagesYearly = result.contentsDamage / result.contentsDamageClaims;
          };
          if(Number.isFinite(result.buildingDamage)){
            averageBuildingDamagesYearly = result.buildingDamage / result.buildingDamageClaims;
          };
          newYearlyAverageDamageItem.textContent = `${yearItem}: $${Math.round(averageContentsDamagesYearly + averageBuildingDamagesYearly).toLocaleString()}`;
          yearlyAverageDamagesElement.appendChild(newYearlyAverageDamageItem);

          const newYearlyAverageReplacementItem = document.createElement("li");
          let averageContentsReplacementsYearly = 0;
          let averageBuildingReplacementsYearly = 0;
          if(Number.isFinite(result.contentsReplacement)){
            averageContentsReplacementsYearly = result.contentsReplacement / result.contentsReplacementClaims;
          };
          if(Number.isFinite(result.buildingReplacement)){
            averageBuildingReplacementsYearly = result.buildingReplacement / result.buildingReplacementClaims;
          };
          newYearlyAverageReplacementItem.textContent = `${yearItem}: $${Math.round(averageContentsReplacementsYearly + averageBuildingReplacementsYearly).toLocaleString()}`;
          yearlyAverageReplacementElement.appendChild(newYearlyAverageReplacementItem);

          const newYearlyAverageClaimsPaidItem = document.createElement("li");
          newYearlyAverageClaimsPaidItem.textContent = `${yearItem}: $${Math.round((result.buildingPaid / result.buildingPaidClaims) + (result.contentsPaid / result.contentsPaidClaims)).toLocaleString()}`;
          yearlyAveragePaidElement.appendChild(newYearlyAverageClaimsPaidItem);
        });

        resolve();
      })
    }
    
    const fetchData = async () => {
      // const endpoint = "https://www.fema.gov/api/open/v2/FimaNfipClaims?$format=jsona";

      const data2014 = require('./data/2014.json');
      const data2015 = require('./data/2015.json');
      const data2016 = require('./data/2016.json');
      const data2017 = require('./data/2017.json');
      const data2018 = require('./data/2018.json');
      const data2019 = require('./data/2019.json');
      const data2020 = require('./data/2020.json');
      const data2021 = require('./data/2021.json');
      const data2022 = require('./data/2022.json');
      const data2023 = require('./data/2023.json');
      const data2024 = require('./data/2024.json');

      const allData = data2014.concat(data2015,data2016,data2017,data2018,data2019,data2020,data2021,data2022,data2023,data2024);

      renderData(allData);
    }

    fetchData();

  };

}, 200);